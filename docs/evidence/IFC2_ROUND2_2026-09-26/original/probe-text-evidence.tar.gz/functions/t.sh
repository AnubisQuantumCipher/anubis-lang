#!/bin/bash
# t.sh prog.anb [from] [to] : ifc2-report, lanes check, runs with the secret literal replaced.
D=/home/sicarii/.cache/anubis-review-esc/ifc2-r2/functions
export TMPDIR=$D/tmp
NEW=/home/sicarii/.cache/anubis-item21/pins/anubis-ifc2-v8e
LANES=/home/sicarii/.cache/anubis-item21/pins/anubis-ord3x4l
W10=/home/sicarii/.cache/anubis-item21/pins/anubis-whole10
ORD=/home/sicarii/.cache/anubis-item21/pins/anubis-ordret2a
CAPS=/home/sicarii/.cache/anubis-item21/capped.sh
f=$1; from=${2:-= 42;}; to=${3:-= 123456;}
b=$(basename $f .anb); O=$D/out/$b; mkdir -p $O
cp $f $O/a.anb
python3 - "$f" "$O/b.anb" "$from" "$to" <<'PY'
import sys
src=open(sys.argv[1]).read()
fr,to=sys.argv[3],sys.argv[4]
assert fr in src, "pattern not found"
open(sys.argv[2],'w').write(src.replace(fr,to,1))
PY
start=$(date +%s.%N)
CAP=1500M timeout 60 $CAPS $NEW ifc2-report $O/a.anb >$O/ifc2 2>&1 ; rc=$?
end=$(date +%s.%N)
CAP=1500M timeout 60 $CAPS $LANES check $O/a.anb >$O/lanes 2>&1 ; rc2=$?
echo "IFC2 rc=$rc ($(python3 -c "print(round($end-$start,2))")s): $(grep -o 'ANUBIS_[A-Z0-9_]*[^\n]*' $O/ifc2 | head -3 | cut -c1-220)"
echo "LANES rc=$rc2: $(grep -o 'ANUBIS_[A-Z_]*' $O/lanes | sort -u | head -5 | tr '\n' ' ')"
if [ "${NORUN:-}" = 1 ]; then exit 0; fi
for R in $NEW $W10 $ORD $LANES; do
  CAP=2G timeout 90 $CAPS $R run --no-verify $O/a.anb >$O/ra 2>&1 ; ra=$?
  if grep -q "ANUBIS_SECRET\|ANUBIS_IMPLICIT\|refus\|ANUBIS_IFC2\|ANUBIS_TAINT" $O/ra && [ $ra -ne 0 ] && ! grep -q "panicked\|ANUBIS_TYPE_ERROR\|ANUBIS_NO_MATCH\|ANUBIS_EMPTY" $O/ra; then
     echo "  runner $(basename $R) refused (rc=$ra): $(head -c 200 $O/ra | tr '\n' ' ')"; continue
  fi
  CAP=2G timeout 90 $CAPS $R run --no-verify $O/b.anb >$O/rb 2>&1 ; rb=$?
  echo "  runner $(basename $R): rcA=$ra rcB=$rb"
  if cmp -s $O/ra $O/rb; then echo "  OUTPUT SAME"; else echo "  OUTPUT DIFFERS"; fi
  echo "  --- A:"; head -c 600 $O/ra | sed 's/^/    /'
  echo "  --- B:"; head -c 600 $O/rb | sed 's/^/    /'
  break
done
