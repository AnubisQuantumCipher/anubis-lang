#!/bin/bash
# usage: probe.sh p/file.anb   (secret literal 42 swapped for 123456 in a copy)
# env: NORUN=1 skip runs
P=$HOME/.cache/anubis-item21/pins
NEW=$P/anubis-ifc2-v8e
LANES=$P/anubis-ord3x4l
CAP=$HOME/.cache/anubis-item21/capped.sh
D=$HOME/.cache/anubis-review-esc/ifc2-r2/precision
export TMPDIR=$D/tmp
f="$1"
n=$(basename "${f%.anb}")
o="$D/out/$n"
sed 's/\b42\b/123456/g' "$f" > "$o.alt.anb"
t0=$(date +%s%N)
CAP=1500M timeout 60 $CAP $NEW ifc2-report "$f" >"$o.new" 2>&1 ; rc=$?
t1=$(date +%s%N)
CAP=1500M timeout 60 $CAP $LANES check "$f" >"$o.lanes" 2>&1 ; rc2=$?
t2=$(date +%s%N)
echo "NEW rc=$rc ($(( (t1-t0)/1000000 ))ms)  LANES rc=$rc2 ($(( (t2-t1)/1000000 ))ms)"
grep -o 'ANUBIS_[A-Z0-9_]*.*' "$o.new" | head -6 | sed 's/^/  NEW: /' | cut -c1-240
grep -o 'ANUBIS_[A-Z0-9_]*' "$o.lanes" | sort | uniq -c | head -5 | sed 's/^/  LANES: /'
if [ "${NORUN:-0}" = 1 ]; then exit 0; fi
for R in anubis-whole10 anubis-ordret2a anubis-ord3x4l anubis-ifc2-v8e IFC2ONLY; do
  B=$P/$R; E=""
  if [ $R = IFC2ONLY ]; then B=$NEW; E="ANUBIS_IFC2=only"; fi
  env $E CAP=2G timeout 90 $CAP $B run --no-verify "$f" 2>"$o.run1.err" >"$o.run1" ; rrc=$?
  if [ $rrc -ne 0 ] && ! grep -q "compiling native" "$o.run1.err"; then continue; fi
  env $E CAP=2G timeout 90 $CAP $B run --no-verify "$o.alt.anb" 2>"$o.run2.err" >"$o.run2" ; rrc2=$?
  echo "RUN[$R] rc=$rrc/$rrc2"
  if cmp -s "$o.run1" "$o.run2" && cmp -s <(grep -v "^anubis run:\|compiling native\|Compiling\|Finished\|Running" "$o.run1.err") <(grep -v "^anubis run:\|compiling native\|Compiling\|Finished\|Running" "$o.run2.err"); then echo "  OUTPUT IDENTICAL"; else echo "  OUTPUT DIFFERS"; fi
  head -c 300 "$o.run1" | sed 's/^/  out42: /'
  if ! cmp -s "$o.run1" "$o.run2"; then head -c 300 "$o.run2" | sed 's/^/  outALT: /'; fi
  grep -v "compiling native" "$o.run1.err" | head -c 300 | sed 's/^/  err42: /'
  exit 0
done
echo "RUN: no runner accepted; trying label-erased twin"; grep -o 'Error: ANUBIS_[A-Z_]*' "$o.run1.err" | head -3
sed 's/secret<\([^<>]*\)>/\1/g; s/secret_source(\([^()]*\))/\1/g' "$f" > "$o.tw.anb"
sed 's/\b42\b/123456/g' "$o.tw.anb" > "$o.tw2.anb"
for R in anubis-ifc2-v8e anubis-whole10 anubis-ordret2a anubis-ord3x4l; do
  B=$P/$R
  CAP=2G timeout 90 $CAP $B run --no-verify "$o.tw.anb" 2>"$o.run1.err" >"$o.run1" ; rrc=$?
  if [ $rrc -ne 0 ] && ! grep -q "compiling native" "$o.run1.err"; then continue; fi
  CAP=2G timeout 90 $CAP $B run --no-verify "$o.tw2.anb" 2>"$o.run2.err" >"$o.run2" ; rrc2=$?
  echo "TWINRUN[$R] rc=$rrc/$rrc2"
  if cmp -s "$o.run1" "$o.run2" && cmp -s <(grep -v "^anubis run:\|compiling native" "$o.run1.err") <(grep -v "^anubis run:\|compiling native" "$o.run2.err"); then echo "  OUTPUT IDENTICAL"; else echo "  OUTPUT DIFFERS"; fi
  head -c 300 "$o.run1" | sed 's/^/  out42: /'
  if ! cmp -s "$o.run1" "$o.run2"; then head -c 300 "$o.run2" | sed 's/^/  outALT: /'; fi
  grep -v "compiling native\|UNVERIFIED\|compile done" "$o.run1.err" | head -c 300 | sed 's/^/  err42: /'
  exit 0
done
echo "TWIN: no runner accepted"; head -c 400 "$o.run1.err"
