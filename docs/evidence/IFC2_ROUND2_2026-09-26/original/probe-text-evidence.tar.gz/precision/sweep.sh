#!/bin/bash
P=$HOME/.cache/anubis-item21/pins
NEW=$P/anubis-ifc2-v8e
LANES=$P/anubis-ord3x4l
CAP=$HOME/.cache/anubis-item21/capped.sh
D=$HOME/.cache/anubis-review-esc/ifc2-r2/precision
export TMPDIR=$D/tmp
cd ~/.cache/anubis-wt/ord3x
out=$D/sweep.tsv
: > $out
find examples tests/fixtures -name '*.anb' | sort | while read f; do
  t0=$(date +%s%N)
  CAP=1500M timeout 30 $CAP $NEW ifc2-report "$f" >$D/sw.new 2>&1 ; rc=$?
  t1=$(date +%s%N)
  c1=$(grep -o 'ANUBIS_[A-Z0-9_]*' $D/sw.new | sort -u | tr '\n' ',')
  rc2=-; c2=""
  if [ $rc -ne 0 ]; then
    CAP=1500M timeout 60 $CAP $LANES check "$f" >$D/sw.lanes 2>&1 ; rc2=$?
    c2=$(grep -o 'ANUBIS_[A-Z0-9_]*' $D/sw.lanes | sort -u | tr '\n' ',')
  fi
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$f" $rc $(( (t1-t0)/1000000 )) "$c1" $rc2 "$c2" >> $out
done
echo DONE >> $out
