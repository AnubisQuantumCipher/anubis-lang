import sys
n=int(sys.argv[1])
names=["Add","Sub","Mul","Div","Mod","Max","Min","Avg","Pow","Shl","Shr","And"][:n]
ops={"Add":"a + b","Sub":"a - b","Mul":"a * b","Div":"if b == 0 { 0 } else { a / b }","Mod":"if b == 0 { 0 } else { a % b }",
     "Max":"if a > b { a } else { b }","Min":"if a < b { a } else { b }","Avg":"(a + b) / 2","Pow":"a * a + b","Shl":"a * 2 + b","Shr":"a / 2 + b","And":"if a != 0 && b != 0 { 1 } else { 0 }"}
out=["// An expression tree in object style: one struct per operator, each with an `eval` method that",
     "// evaluates its children through method calls, and a `show` method that renders it.",
     "struct Num {", "    v: i64,", "}", "",
     "impl Num {", "    fn eval(self) -> i64 {", "        return self.v;", "    }",
     "    fn show(self) -> str {", "        return str(self.v);", "    }", "}", ""]
for nm in names:
    out += [f"struct {nm} {{", "    l: Num,", "    r: Num,", "}", "",
            f"impl {nm} {{", "    fn eval(self) -> i64 {", "        let a = self.l.eval();", "        let b = self.r.eval();",
            f"        return {ops[nm]};", "    }",
            "    fn show(self) -> str {", f"        return \"{nm.lower()}(\" + self.l.show() + \", \" + self.r.show() + \")\";", "    }", "}", ""]
# build a tree
def build(i, depth):
    if depth == 0:
        return f"Num {{ v: {i+1} }}"
    nm = names[(i+depth) % len(names)]
    return f"{nm} {{ l: {build(i*2, depth-1)}, r: {build(i*2+1, depth-1)} }}"
out += ["fn main() {",
        "    let k: secret<i64> = 42;",
        f"    let e = {build(1, 4)};",
        "    print(e.show() + \" = \" + str(e.eval()));",
        f"    let h = {names[0]} {{ l: Num {{ v: k }}, r: e }};",
        "    assert(h.eval() > -1000000000);",
        "}"]
print("\n".join(out))
