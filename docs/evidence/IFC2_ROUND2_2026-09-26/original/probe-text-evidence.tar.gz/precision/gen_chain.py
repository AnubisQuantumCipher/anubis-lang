import sys
n=int(sys.argv[1])
out=["// A parser with one function per precedence level: level i parses level i+1 operands",
     "// joined by operator ops[i]; the last level parses a number or a parenthesized expression.",
     "enum Ast {", "    Num(i64),", "    Bin(str, Ast, Ast),", "}", "",
     "fn peek(toks, p) {", "    if p < len(toks) {", "        return toks[p];", "    }", "    return \"\";", "}", ""]
ops=["+","-","*","/","%","&","|","^","<",">","=","~","@","#"]
for i in range(1,n):
    out += [f"fn level{i}(toks, p) {{",
            f"    let r = level{i+1}(toks, p);",
            "    let mut node = r[0];",
            "    let mut q = r[1];",
            f"    while peek(toks, q) == \"{ops[i-1]}\" {{",
            f"        let r2 = level{i+1}(toks, q + 1);",
            f"        node = Ast::Bin(\"{ops[i-1]}\", node, r2[0]);",
            "        q = r2[1];",
            "    }",
            "    return [node, q];",
            "}", ""]
out += [f"fn level{n}(toks, p) {{",
        "    if peek(toks, p) == \"(\" {",
        "        let r = level1(toks, p + 1);",
        "        return [r[0], r[1] + 1];",
        "    }",
        "    return [Ast::Num(int(peek(toks, p))), p + 1];",
        "}", "",
        "fn size(a) {",
        "    return match a {",
        "        Ast::Num(x) => 1,",
        "        Ast::Bin(o, l, r) => 1 + size(l) + size(r),",
        "    };",
        "}", "",
        "fn main() {",
        "    let toks = [\"(\", \"1\", \"+\", \"2\", \")\", \"*\", \"3\"];",
        "    let r = level1(toks, 0);",
        "    print(\"nodes: \" + str(size(r[0])));",
        "}"]
print("\n".join(out))
