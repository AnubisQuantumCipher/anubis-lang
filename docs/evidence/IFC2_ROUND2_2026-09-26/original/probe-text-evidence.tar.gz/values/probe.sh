#!/bin/bash
# probe.sh f.anb [runner...]  -- ifc2-report (NEW), lanes check, and runs with secret 42 vs 123456.
# Writes results under ./out/<name>.*
D=/home/sicarii/.cache/anubis-review-esc/ifc2-r2/values
CAPPED=/home/sicarii/.cache/anubis-item21/capped.sh
NEW=/home/sicarii/.cache/anubis-item21/pins/anubis-ifc2-v8e
LANES=/home/sicarii/.cache/anubis-item21/pins/anubis-ord3x4l
W10=/home/sicarii/.cache/anubis-item21/pins/anubis-whole10
ORD=/home/sicarii/.cache/anubis-item21/pins/anubis-ordret2a
f="$1"; shift
name=$(basename "$f" .anb)
mkdir -p "$D/out"
o="$D/out/$name"
cd "$D"
t0=$(date +%s.%N)
CAP=1500M timeout 60 $CAPPED $NEW ifc2-report "$f" >"$o.ifc" 2>&1 ; rc=$?
t1=$(date +%s.%N)
CAP=1500M timeout 60 $CAPPED $LANES check "$f" >"$o.lanes" 2>&1 ; rc2=$?
echo "IFC2 rc=$rc ($(python3 -c "print(round($t1-$t0,2))")s): $(grep -o 'ANUBIS_[A-Z0-9_]*' "$o.ifc" | sort -u | tr '\n' ' ')"
echo "LANES rc=$rc2: $(grep -o 'ANUBIS_[A-Z0-9_]*' "$o.lanes" | sort -u | tr '\n' ' ')"
sed 's/= 42;/= 123456;/' "$f" > "$D/out/${name}__k2.anb"
runners=("$@")
if [ ${#runners[@]} -eq 0 ]; then runners=(NEW); fi
for r in "${runners[@]}"; do
  f1="$f"; f2="$D/out/${name}__k2.anb"
  case $r in NEW) B=$NEW;; W10) B=$W10;; ORD) B=$ORD;; LANES) B=$LANES;;
    PUB) B=$NEW; sed 's/secret<i64>/i64/' "$f" > "$D/out/${name}__pub1.anb"; sed 's/secret<i64>/i64/' "$f2" > "$D/out/${name}__pub2.anb"; f1="$D/out/${name}__pub1.anb"; f2="$D/out/${name}__pub2.anb";; esac
  CAP=2G timeout 90 $CAPPED $B run --no-verify "$f1" >"$o.run1.$r" 2>&1 ; rrc1=$?
  CAP=2G timeout 90 $CAPPED $B run --no-verify "$f2" >"$o.run2.$r" 2>&1 ; rrc2=$?
  if cmp -s "$o.run1.$r" "$o.run2.$r"; then same=SAME; else same=DIFF; fi
  echo "RUN[$r] rc=$rrc1/$rrc2 $same"
  echo "  k42: $(grep -v UNVERIFIED_EXECUTION "$o.run1.$r" | head -c 400 | tr '\n' '|')"
  echo "  k2 : $(grep -v UNVERIFIED_EXECUTION "$o.run2.$r" | head -c 400 | tr '\n' '|')"
done
