#!/bin/bash
# usage: probe.sh file.anb [secretA secretB]  -- runs ifc2-report, lanes check, and NEW run with two secret values
# The secret literal to substitute is marked with 42 in the file on the line containing SECRET (or first "= 42;")
set -u
D=~/.cache/anubis-review-esc/ifc2-r2/parity
NEW=~/.cache/anubis-item21/pins/anubis-ifc2-v8e
LANES=~/.cache/anubis-item21/pins/anubis-ord3x4l
f="$1"; A="${2:-42}"; B="${3:-123456}"
base="${f%.anb}"
CAP=1500M timeout 60 ~/.cache/anubis-item21/capped.sh $NEW ifc2-report "$f" >"$base.ifc" 2>&1 ; rc=$?
echo "IFC2 rc=$rc"; head -c 1500 "$base.ifc"
CAP=1500M timeout 60 ~/.cache/anubis-item21/capped.sh $LANES check "$f" >"$base.lanes" 2>&1 ; rc2=$?
echo "LANES rc=$rc2"; grep -o 'ANUBIS_[A-Z_]*' "$base.lanes" | sort | uniq -c | head
sed "s/\b42\b/$A/" "$f" > "$base.A.anb"
sed "s/\b42\b/$B/" "$f" > "$base.B.anb"
RUNNER="${RUNNER:-$NEW}"
CAP=2G timeout 90 ~/.cache/anubis-item21/capped.sh $RUNNER run --no-verify "$base.A.anb" >"$base.runA" 2>&1 ; ra=$?
CAP=2G timeout 90 ~/.cache/anubis-item21/capped.sh $RUNNER run --no-verify "$base.B.anb" >"$base.runB" 2>&1 ; rb=$?
echo "RUN A rc=$ra:"; head -c 800 "$base.runA"; echo "RUN B rc=$rb:"; head -c 800 "$base.runB"
sed -E "s/\(([0-9]+)\) panicked/(TID) panicked/" "$base.runA" > "$base.nA"; sed -E "s/\(([0-9]+)\) panicked/(TID) panicked/" "$base.runB" > "$base.nB"
if cmp -s "$base.nA" "$base.nB"; then echo "== SAME output"; else echo "== DIFFERENT output"; fi
