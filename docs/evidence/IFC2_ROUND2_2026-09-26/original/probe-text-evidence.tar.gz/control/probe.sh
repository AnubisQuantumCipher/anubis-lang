#!/bin/bash
# usage: probe.sh name 'sed-expr' [runner]
# name.anb in p/; variant B made by sed-expr. Runs NEW ifc2-report, LANES check, and runtime on both.
D=/home/sicarii/.cache/anubis-review-esc/ifc2-r2/control/p
P=/home/sicarii/.cache/anubis-item21/pins
NEW=$P/anubis-ifc2-v8e
LANES=$P/anubis-ord3x4l
C=/home/sicarii/.cache/anubis-item21/capped.sh
n=$1; sx=$2; runner=${3:-$NEW}
cd $D
sed "$sx" $n.anb > ${n}_b.anb
if cmp -s $n.anb ${n}_b.anb; then echo "WARN: variant identical"; fi
t0=$(date +%s%N)
CAP=1500M timeout 60 $C $NEW ifc2-report $n.anb >$n.ifc 2>&1 ; rc=$?
t1=$(date +%s%N)
echo "== ifc2-report rc=$rc time=$(( (t1 - t0)/1000000 ))ms"; grep -o 'ANUBIS_[A-Z0-9_]*[^"]*' $n.ifc | head -5; tail -c 300 $n.ifc | grep -v ANUBIS | head -3
if [ "${NOLANES:-0}" != 1 ]; then
CAP=1500M timeout 60 $C $LANES check $n.anb >$n.lanes 2>&1 ; rc2=$?
echo "== lanes rc=$rc2"; grep -o 'ANUBIS_[A-Z0-9_]*' $n.lanes | sort | uniq -c | head -5
fi
if [ "${NORUN:-0}" != 1 ]; then
CAP=2G timeout 90 $C $runner run --no-verify $n.anb >$n.outA 2>&1 ; ra=$?
CAP=2G timeout 90 $C $runner run --no-verify ${n}_b.anb >$n.outB 2>&1 ; rb=$?
echo "== run A rc=$ra"; head -c 600 $n.outA; echo
echo "== run B rc=$rb"; head -c 600 $n.outB; echo
if cmp -s $n.outA $n.outB && [ $ra = $rb ]; then echo "== SAME"; else echo "== DIFFER"; fi
fi
